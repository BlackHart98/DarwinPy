# This is an abstract class from which other classes are derived

class Core:
    def __init__(self):
        pass

    def epoch(self):
        pass

    def mutate(self):
        pass
