error = (
{
"E0001" : "METHOD MISMATCH -> the called method does not instantiated type",
"E0002" : "INVALID CLASS -> class does not exist, check for mispelled DarwinPy class"
}
)

warning = (
{
"W0001" : ""
}
)

misc = (
{
"MISC #1" : ""
}
)
